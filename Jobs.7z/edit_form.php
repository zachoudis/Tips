<?php
    include('main.php');
        
    $id= $_GET['id'];
    $con = mysqli_connect('localhost','root','1122','jobs');
    $result = mysqli_query($con,"SELECT * FROM tasks WHERE Id='".$id."';");   
    $row = mysqli_fetch_array($result); 
    
    if ($row['state'] == "Finished" OR $row['state'] == "Cancelled")      
        echo('<h3  >Finished Or Cancelled Tasks Cannot Be Edited</h3>');
    else {?>
    <form method="post" id="form2" action=""  name="form_service" >
        <table>
                <tr>
                    <td>Ημερομηνία Αναθεσης</td>
                    <td><input type="date" name="date_entry" id="datepicker4" value="<?php echo $row['date_entry'] ?>" required  maxlength="15" />ex. 2000-10-25</td>
                </tr><tr>
                    <td>Deadline</td>
                    <td><input type="date" name="deadline" id="datepicker3" value="<?php echo $row['deadline'] ?>" maxlength="15" />ex. 2000-10-25</td>
                </tr><tr>
                    <td>Πρακτικο Συσκεψης</td>
                    <td><input type="text" name="praktiko" value="<?php echo $row['praktiko'] ?>"size="80"  maxlength="80" /></td>
                </tr><tr>
                    <td>Περιγραφη</td>
                    <td><textarea  rows="5" cols="60" type="text" name="description" id="description" size="100" required maxlength="300" ><?php echo $row['description'] ?></textarea></td>	
                </tr><tr>
                    <td>Υπευθυνος</td>
                    <td colspan="2">
                        <select id="jobkind" name="ipey8inos" required class="box" >
                            <option value="" >---Επιλέξτε---</option>
                            <?php 
                                for ($i=0;$i<$length;$i++)
                                if ($row['ipey8inos']==$users[$i])
                                   echo "<option value='".$users[$i]."' selected>".$users[$i]."</option>";
                                else
                                   echo "<option value='".$users[$i]."'>".$users[$i]."</option>";
                            ?>
                        </select>	
                    </td>
                </tr><tr>
                    <td>Εκδοθηκε Απο</td>
                    <td colspan="2">
                        <select id="jobkind" name="ekdosh" class="box" >
                           <option value="">---Επιλέξτε---</option>
                           <option value="Ανθιμος" <?php if($row['ekdosh'] == 'Ανθιμος') echo "selected";?>>Ανθιμος</option>
                           <option value="Βασιλική" <?php if($row['ekdosh'] == 'Βασιλική') echo "selected";?>>Βασιλική</option>
                        </select>
                    </td>
                </tr><tr>
                    <td>Σχολια </td>
                    <td><textarea  rows="2" cols="60" type="text" name="comments"    size="100"  maxlength="300" ><?php echo $row['comments'] ?></textarea></td>					
                </tr><tr>
                    <td colspan="3">
                        <input class="button" type="hidden" value="<?php echo $id; ?>" name="Id" />
                        <input class="button" type="submit" value="Καταχώριση" name="edit" />
                        <button onclick="javascript:showhide('edit_form')" value="Ακυρωση">Κλεισιμο</button>
                    </td>
                </tr>			
          </table>
     </form>       
<?php } ?>