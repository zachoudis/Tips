<!DOCTYPE html>
<html>
<head>
</head>

<body>
<?php
    include 'main.php';
    $state= $_GET['q'];
    $id =  $_GET['id'];
    $comment = $_GET['comment'];

    change_previous_tasks($id,$ids,$state);

    //If the state was PENDING and Changed to FINISHED OR CANCELLED
    if ($state == 'Finished' OR $state == 'Cancelled') {
        
        //Database Connection
        $con = mysqli_connect('localhost','root','1122','jobs');
        if (!$con) { die('Could not connect: ' . mysqli_error($con));}
 
        $curr_date=date("Y-m-d");
        //Gets the Deadline from the database
        $sql2="SELECT deadline FROM tasks WHERE id=".$id;
        $result2 = mysqli_query($con,$sql2);
        $row = $result2->fetch_assoc();
        
        //Gets the already inserted comment  and add the new one       
        $comment=get_old_comment($con,$id,$comment);
        
        //If there is a deadline
        if ($row["deadline"]!=null){
            $deadline=$row["deadline"];

            if ($state == "Finished"){
                if ($curr_date<=$deadline)
                    $sql="UPDATE tasks SET date_finished='".$curr_date."' ,state='".$state."'  ,comments='".$comment."' WHERE id =".$id;
                else if ($curr_date>$deadline){
                   // $ts1 = strtotime($deadline);$ts2 = strtotime($curr_date);     
                    $delay =  (strtotime($curr_date) - strtotime($deadline))/(60 * 60 * 24);
                    $sql="UPDATE tasks SET date_finished='".$curr_date."',delay='".$delay."' ,state='".$state."'  ,comments='".$comment."' WHERE id =".$id;           
                }
            }
            else if ($state == "Cancelled")
                $sql="UPDATE tasks SET state='".$state."',comments='".$comment."' WHERE id =".$id;
        }
        //If there is not a deadline
        else {
            if ($state == "Finished")             
                $sql="UPDATE tasks SET date_finished='".$curr_date."' ,state='".$state."'  ,comments='".$comment."' WHERE id =".$id;     
            else if ($state == "Cancelled")
                $sql="UPDATE tasks SET state='".$state."',comments='".$comment."' WHERE id =".$id;
        }
        $result = mysqli_query($con,$sql);         
        }
    
?>

</body>
</html>