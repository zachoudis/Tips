 <script src="javascript.js"></script> 
<?php
  include('session.php');
  include('main.php');
  $results_per_page=7;
  //<h5><a href="javascript:fnExcelReport('projects','<?php echo return_name($user_check);  ',document.getElementById('task_filter2').value)" >Export Excel</a></h5> 

?>
<html>
   <head> 
       <title>T.i.P. Yetos </title>
        <script type="text/javascript" src="jQuery.js"></script>
        <script type="text/javascript" src="ExcelExportJs-master/src/Scripts/jquery.techbytarun.excelexportjs.js"></script>
        <link rel="stylesheet" type="text/css" href="style.css">     
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        <script>
      
              $(document).ready(function() {
                $("#datepicker").datepicker();
              });
              $(document).ready(function() {
                $("#datepicker2").datepicker();
              });
              $(document).ready(function() {
                $("#datepicker3").datepicker();
              });
              $(document).ready(function() {
                $("#datepicker4").datepicker();
              });

              function change(string) {        
                    $(document).ready(function() {
                      $("#user_filter2").val(string);             
                      });
               }
               
              function alert_link(){
                     update_view(this.value);     
               } 
              function change_color_alert(name,noname){
                 // alert(name);
                  document.getElementById(name).style.color = "red";            
                  document.getElementById(noname).style.visibility="hidden";
                }
              function change_color_alert2(name,noname){
                 // alert(name);
                  document.getElementById(name).style.visibility = "hidden";            
                  document.getElementById(noname).style.visibility="";
                }

        </script>



   </head>

   
   <body onload="update_view(this.value)">
  
        <?php
            if ( $user_check!= "span" AND  $user_check!="kova"){
                change_auto_filter($user_check); check_for_delays($user_check,$delayed_task,$ids);
            }?>
      
       <div id="panel" class="panel">
            <img  src="logo2.jpg" class="logo" alt="yetos" style="width:379px;height:99px;">
            <div class="container">
                <h1>T.i.P. Υετός </h1> <?php get_name($user_check);?>
                </div></div>
         <div id="signout" >   
                    <form class="signout" action="logout.php"> 
                      <input type="image" src="images.jpg" alt="Submit" width="68" height="68">
         </form></div>
       <div id="maincontent">             
           <div id="filters" class="filters">                 
                <div class="task">
                <h3>Filter by Task </h3>
                    <select onchange="update_view(this.value)" id="task_filter2" name="task_filter2" class="user_filter2" >
                        <option value="Pending">Pending</option>
                        <option value='Ολες'>All</option>
                        <option value="Finished">Finished</option>
                        <option value="Cancelled">Cancelled</option>
                    </select> 
                </div>
                <div class="user">
                <h3>Filter by User </h3>
                    <select onchange="update_view(this.value)" id="user_filter2" name="user_filter2" class="user_filter2" >
                      <option value="Ολοι">All</option>
                      <?php 
                         for ($i=0;$i<$length;$i++)
                            echo "<option value='".$users[$i]."'>".$users[$i]."</option>"
                      ?>
                    </select>
                </div>
                <div class="department">
                 <h3>Filter by Department </h3>
                    <select onchange="update_view(this.value)" id="dep_filter2" name="user_filter2" class="user_filter2" >                          
                       <option value="Ολα">All</option>
                        <?php 
                          for ($i=0;$i<count($departments);$i++)
                            echo "<option value='".$departments[$i]."'>".$departments[$i]."</option>"
                        ?>                        
                    </select>
                </div>
               <div class="deadlines_not">
                 <h3>Filter by Deadlines </h3>
                    <select onchange="update_view(this.value)" id="deadline_filter2" name="user_filter2" class="user_filter2" >                          
                       <option value="All">All</option>
                       <option value="NOT">With Deadline</option>
                       <option value=" ">Without Deadline</option>          
                    </select>
                </div>
               <div class="entolh_apo">
                 <h3>Filter by Entolh </h3>
                    <select onchange="update_view(this.value)" id="entolh_filter2" name="user_filter2" class="user_filter2" >                          
                       <option value="All">All</option>
                        <?php 
                           for ($i=0;$i<count($persons_to_give_orders);$i++)
                            echo "<option value='".$persons_to_give_orders[$i]."'>".$persons_to_give_orders[$i]."</option>"
                        ?>                        
                    </select>
                </div>
               <div class='check_box'>
                   <h3>Filter  </h3>
                   <input type="checkbox" onchange="update_view(this.value)" value="check" id='last_filters2'>Show only Last Task<br>
               </div>
            </div>

           <?php if ( $user_check== "span" OR  $user_check=="kova"){ ?>
             <div class="manager_filters">          
                <div id="delay_pending" class="delay_pending"> 
                    <h3>Delayed Pending</h3><input type="checkbox" class="check_box"  onclick="checkbox_view('1')" id="check1">   
                </div>
                <div id="delay_finished" class="delay_finished"> 
                    <h3>Delayed Finished</h3><input type="checkbox" class="check_box"  onclick="checkbox_view('2')" id="check2"> 
                </div>
             </div>
          <?php } ?>
                   
           <div class='alerts' >
                <div class="team1"><span class="noblink" id="noblink">You Have No Delayed Tasks</span></div>
                <div class="team2"><span class="noblink" id="noblink2">You Have No Tasks Ending Today</span></div>    
                <div class="team1"><span class="blink"   id="blink">You Have Delayed Tasks</span></div>
                <div class="team2"><span class="blink"   id="blink2" >You Have Tasks Ending Today</span></div>    
                <?php
                    if ($GLOBALS['delayed_task'] == 1)
                      echo '<script type="text/javascript">change_color_alert("blink","noblink");</script>';
                    else
                      echo '<script type="text/javascript">change_color_alert2("blink","noblink");</script>';
                    if ($GLOBALS['task_ending_today'] == 1)
                      echo '<script type="text/javascript">change_color_alert("blink2","noblink2");</script>';
                    else
                      echo '<script type="text/javascript">change_color_alert2("blink2","noblink2");</script>';
                ?>
           </div>
           
           <div id="main" class="main">                            
                <div class="links">
                    <div id="insert" class="insert"> 
                     
                       <h5 ><a href="javascript:showhide('insert_form')">Insert Task</a></h5> 
                    </div>
                    <div class="pages">
                            
                        <a class="pages_button_previous">Previous    </a>
                        <span>
                         
                            <a class="pages_button">1</a>
                            <a class="pages_button">2</a>
                            <a class="pages_button">3</a>
                            <a class="pages_button">4</a>
                            <a class="pages_button">...</a>
                            <a class="pages_button">10</a>
                        </span>
                        <a>Next</a>
                    </div>
                    <div id="export" class="export"> 
                        <h5><a href="javascript:fnExcelReport('projects','<?php echo return_name($user_check); ?> ',document.getElementById('task_filter2').value)" >Export Excel</a></h5>    
                    </div>
                </div>
                <div id="insert_form"  style="display:none;" class="form"> 
                    <form method="post" action=""  name="form_service" onsubmit="return validateForm()" >    
                    <table>
                        <tr>
                            <td>Ημερομηνία Ανάθεσης</td>
                            <td><span class="asterisk">*</span><input type="date" name="date_entry" id="datepicker2" required  maxlength="15" /></td>        
                        </tr><tr>
                            <td>Deadline</td>
                            <td><input type="date" name="deadline" id="datepicker"  maxlength="15" /></td>
                        </tr><tr>
                            <td>Πρακτικό Σύσκεψης</td>
                            <td><input type="text" name="praktiko" size="80"  maxlength="15" /></td>
                        </tr><tr>
                            <td>Περιγραφή</td>
                            <td><span class="asterisk">*</span><textarea  rows="5" cols="60" type="text" name="description" id="description" size="100" required maxlength="300" ></textarea></td>	
                        </tr><tr>
                            <td>Υπεύθυνος</td>
                            <td colspan="2"><span class="asterisk">*</span>
                                <select id="jobkind" name="ipey8inos" required class="box" >
                                    <option value="">---Επιλέξτε---</option>
                                    <?php 
                                        for ($i=0;$i<$length;$i++)
                                            echo "<option value='".$users[$i]."'>".$users[$i]."</option>"
                                     ?>
                                </select>	
                            </td>
                        </tr>    
                         <td>Εντολή Από</td>
                            <td colspan="2">
                                <select id="jobkind" name="ekdosh" class="box" >
                                    <option value="">---Επιλέξτε---</option>
                                    <option value="Ανθιμος">Άνθιμος</option>
                                    <option value="Βασιλική">Βασιλική</option>
                                </select>
                            </td>
                        </tr><tr>
                            <td>Σχολια</td>
                             <td><textarea  rows="2" cols="60" type="text" name="comments" size="100"  maxlength="300" ></textarea></td>	 		
                        </tr><tr>
                            <td colspan="3">
                                <input class="button" type="submit" value="Καταχώριση" name="submit" />
                                <input class="button" type="reset" value="Καθαρισμός" name="cleaner" />
                                <button onclick="javascript:showhide('insert_form')" value="Ακυρωση">Κλεισιμο</button>
                                <br><span class="asterisk">*required fields</span>
                            </td>
                        </tr>			
                    </table>
                 </form>
                </div>            
                <div id="edit_form"  style="display:none;" class="edit_form">  </div>  
                <div  class="txtHint"  id="txtHint"><b></b></div>   
           </div>      
       </div>  

       
      
       
       
       
       <div class="test">
            <?php   
           $total_pages=calculate_total_records($results_per_page);
            for ($i=1; $i<=$total_pages; $i++) { 
        //        echo "<a href='index.php?page=".$i."'>".$i."</a> "; 
            }; 
            ?>
       </div>
       
       
       <div class="inout" id="inout" hidden="" > 
         
            <form method="post" action=""  name="form_inout" >
                <input type="date" name="date2" id="datepicker3" class='drop' maxlength="15" value="Select a Date"/>
                <input class="button" type="submit" value="Καταχώριση" class='drop' name="submit_inout" />
            </form>
           
            <div id="export2" class="export2"> 
                <h4><a href="javascript:fnExcelReport('excel_inout')">Export Excel</a></h4> 
            </div>
           
           
            <table border='1' id="excel_inout" class="table">
                <tr>
                    <th class="lines" style="background-color: #E1E2E1;" >A/A</th>
                    <th class="lines" width="30%" style="background-color: #E1E2E1;">Name</th>              
                    <th class="lines" width="20%" style="background-color: #E1E2E1;">In</th>              
                    <th class="lines" width="10%" style="background-color: #E1E2E1;">Ωραριο Μισθωτων</th>
                    <th class="lines" style="background-color: #E1E2E1;">Comments</th>
                </tr>  
 
                <?php
                if(isset( $_POST['submit_inout'] )){
                    
              //      $result6 = odbc_exec($conn2,$sql6);
                 /*   while($row = odbc_fetch_array($result6)){   
                        echo"<tr>";
                         $query="SELECT username, person_id FROM Users WHERE ID=".$row['user']."; ";
                         $result = odbc_exec($conn2,$query);
                         $row2 = odbc_fetch_array($result);
                         $username= $row2['username'];  
                       //  $query2="SELECT PersonName FROM persons WHERE PersonID=".$row2['person_id'].";";
                     //    $result_p=odbc_exec($conn2,$query2);
                    //     $row3 = odbc_fetch_array($result_p);
               
                         echo "<td class='lines'> </td>";
                         echo "<td class='lines'> ONOMATEPWNYMo </td>";
                         echo "<td class='lines'>" . $username. "</td>";
                         echo "<td class='lines'>" .substr( $row['day'] , 0,10). "</td>";
                         echo "<td class='lines'>" .substr( $row['in_time'] , 11,8)  . "</td>";
                         echo "<td class='lines'>" .substr( $row['out_time'] , 11,8). "</td>";
                         echo "<td class='lines'> </td>";
                         echo "<td class='lines'> </td>";
                         echo "</tr>";
                    }*/
                        echo "<h3 class-'day'>  Day : ".$_POST['date2']."</h3>";
                    for ($i=0;$i<41;$i++){
                        $aa=$i+1;
                    
                         echo"<tr>";
                         echo "<td class='lines' style='background-color:#CDE8F6'>".$aa." </td>";
                         echo "<td class='lines' style='background-color:#CDE8F6'> ".$users_inout[$i][0]." </td>";
                         echo "<td class='lines' style='background-color:#CDE8F6'>".substr( $array_in[$i],11,8)."</td>";
                         echo "<td class='lines' style='background-color:#CDE8F6'>".$users_inout[$i][2]." </td>";
                         echo "<td class='lines' style='background-color:#CDE8F6'> </td>";
                         echo "</tr>";

                    }
                  }
                ?>     	
            </table>

       </div>
        </body> 
</html>
