<?php
include ('welcome.php');
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$start_from = ($page-1) * $results_per_page;
 $db = mysqli_connect('localhost','root','1122','jobs');
$sql = "SELECT * FROM tasks ORDER BY Id ASC LIMIT $start_from, ".$results_per_page;
$rs_result = mysqli_query($db,$sql); 
 

?> 
<table border="1" cellpadding="4">
<tr>
    <td bgcolor="#CCCCCC"><strong>ID</strong></td>
    <td bgcolor="#CCCCCC"><strong>Name</strong></td><td bgcolor="#CCCCCC"><strong>Phone</strong></td></tr>
<?php 
 while($row = $rs_result->fetch_assoc()) {
?> 
            <tr>
            <td><? echo $row["Id"]; ?></td>
            <td><? echo $row["date_entry"]; ?></td>
            <td><? echo $row["deadline"]; ?></td>
            </tr>
<?php 
}; 
?> 
</table>