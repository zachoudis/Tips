<?php
    include('session.php');

    if($db === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

  $date_entry='';
    $date_entry = mysqli_real_escape_string($db, $_POST['date_entry']);
    $deadline = mysqli_real_escape_string($db, $_POST['deadline']);
    $date_finished = mysqli_real_escape_string($db, $_POST['date_finished']);
    $delay = mysqli_real_escape_string($db, $_POST['delay']);
    $description = mysqli_real_escape_string($db, $_POST['description']);
    $department = mysqli_real_escape_string($db, $_POST['department']);
    $ipey8ions = mysqli_real_escape_string($db, $_POST['ipey8inos']);
    $comments = mysqli_real_escape_string($db, $_POST['comments']); 

    // attempt insert query execution

    $sql = "INSERT INTO tasks (date_entry, deadline, date_finished , delay , description , department , ipey8inos , comments ) VALUES ('$date_entry', '$deadline', '$date_finished' , '$delay' , '$description' ,'$department' , '$ipey8ions' , '$comments')";

    if(mysqli_query($db, $sql)){
        echo "Records added successfully.";
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);
    }
    mysqli_close($db);

    
    ?>

