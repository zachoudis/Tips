<!DOCTYPE html>.

<?php
  include('main.php');
?>
<html>
<head>
</head>
<body>

<?php
    $value_user= $_GET['str']; $value_filters =  $_GET['str2']; $value_dep = $_GET['str3']; $value_deadline = $_GET['str4'];  $value_entolh = $_GET['str5']; $value_last = $_GET['str6'];

    $con = mysqli_connect('localhost','root','1122','jobs');
    if (!$con) {die('Could not connect: ' . mysqli_error($con)); }

    if ($value_filters=='Ολες') $task_f='';  else $task_f="AND state='".$value_filters."'" ;  
    if ($value_user=='Ολοι') $task_u=''; else $task_u="AND ipey8inos='".$value_user."'";
    if ($value_dep == 'Ολα') $task_d=''; else $task_d="AND department='".$value_dep."'";
    if ($value_entolh =='All') $task_e=''; else $task_e="AND ekdosh='".$value_entolh."'";
    if ($value_deadline=='All') $task_de=''; else $task_de="AND deadline IS ".$value_deadline."  NULL";
    if ($value_last == 'false') $task_l=''; else $task_l=" AND Id LIKE '%.00%'";
 //   echo $value_last;
    $str="SELECT * FROM tasks WHERE ".$task_f."".$task_u."".$task_d."".$task_e."".$task_de."".$task_l." ORDER BY Id ASC  ";
  //  echo $str;
    if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_deadline=='All' and $value_entolh == 'All') {
       if ($value_last == 'false')
          $result = mysqli_query($con,"SELECT * FROM tasks  ORDER BY Id ASC");       
      else 
          $result = mysqli_query($con,"SELECT * FROM tasks WHERE Id LIKE '%.00%'  ORDER BY Id ASC"); 
    }
       else
        $result= mysqli_query($con,substr($str, 0, 25)." ".substr($str,30));
    
    
    
    
    
    
?>
    <table  id="projects" class="table">                   
        <tr>        
            <th class="title" >A/A</th>
            <th class="title" width="100" >Hμερομηνία Έναρξης</th>
            <th class="title" width="100">Deadline</th>
            <th class="title" width="120">Ημερομηνία Ολοκλήρωσης</th>
            <th class="title" >Delay</th>
            <th class="title" >Πρακτικό Σύσκεψης</th>
            <th class="title" >Περιγραφή</th>
            <th class="title" >Τμήμα</th>
            <th class="title" >Υπεύθυνος Ενέργειας</th>
            <th class="title" >Εντολή Από</th>
            <th class="title" >Σχόλιο-Αναφορά Εκτέλεσης</th>
            <th class="title" >Edit</th>
            <th class="title" >Κατάσταση</th>
        </tr>       
        <?php
         while($row = mysqli_fetch_array($result)){   
             
            if ($row['state']=='Finished') {$color='lightgreen';} else if ($row['state'] == 'Cancelled')$color='lightcoral'; else $color='orange';
            echo "<tr  href='insert.php' >";
            //ID
            echo "<td  class='lines' >" .check_id($row['Id'])  . "</td>";
            //DATE START
            echo "<td  class='lines' align='center'>" . date('d/m/Y', strtotime($row['date_entry'])) . "</td>";
            //DEADLINE
            echo "<td  class='lines' align='center'>" .check_if_null($row['deadline']). "</td>";
            //DATE FINISHED      
            echo "<td  class='lines' align='center'>" .check_if_null($row['date_finished']) . "</td>"; 
            //DELAY
            echo "<td  class='lines' align='center'>" . $row['delay'] . "</td>";
            //PRAKTIKO
            echo "<td  class='lines'>" . $row['praktiko'] . "</td>";
            //DESCRIPTION
            echo "<td  class='lines'>" . put_lines_description($row['description']) . "</td>";
            //DEPARTMENT
            echo "<td  class='lines' align='center'>" . $row['department'] . "</td>";
            //IPEY*INOS
            echo "<td  class='lines'>" . $row['ipey8inos'] . "</td>";
            //ENTOLH APO
            echo "<td  class='lines' align='center'>" . $row['ekdosh']   .  "</td>";
            //COMMENTS
            echo "<td  class='lines'>" . $row['comments'] . "</td>";  

            //EDIT BUTTON
            if ($row['state']=='Finished' OR $row['state']=='Cancelled' ) 
                echo "<td class='lines'> <button disabled  '>edit</button></td>";
            else if ($row['state']=='Pending')
                if (check_for_newer_version($row['Id'],$ids)==1 )
                   echo "<td class='lines'> <button disabled  '>edit</button></td>";
                else
                   echo "<td class='lines'> <button  onclick='edituser(".$row['Id'].")'>edit</button></td>";
               
            //STATE
            $pending=''; $cancelled=''; $finished='';
            if ($row['state'] == 'Finished') {
                $finished =  'selected';
                echo "<td class='lines'> <select disabled  style='background-color:".$color."' id='test'> <option class='pending' value='Pending' ". $pending ." >Pending</option> <option value='Finished' ". $finished ." >Finished</option> <option  value='Cancelled' ". $cancelled ." >Cancelled</option> </select> </td>";
            }   
            else if ($row['state'] == 'Cancelled'){
                $cancelled = 'selected';
                echo "<td class='lines' > <select disabled  style='background-color:".$color."' id='test'> <option class='pending' value='Pending' ". $pending ." >Pending</option> <option value='Finished' ". $finished ." >Finished</option> <option  value='Cancelled' ". $cancelled ." >Cancelled</option> </select> </td>"; 
            }
            else if ($row['state'] == 'Pending'){
                $pending = 'selected';
                if (check_for_newer_version($row['Id'],$ids)==1 )
                    echo "<td  class='lines'> <select style='background-color:".$color."' disabled id='test' onchange='cancel_message(this.value,".$row['Id'].")' > <option class='pending' value='Pending' ". $pending ." >Pending</option> <option value='Finished' ". $finished ." >Finished</option> <option  value='Cancelled' ". $cancelled ." >Cancelled</option> </select> </td>";
                else
                    echo "<td  class='lines'> <select style='background-color:".$color."' id='test' onchange='cancel_message(this.value,".$row['Id'].")' > <option class='pending' value='Pending' ". $pending ." >Pending</option> <option value='Finished' ". $finished ." >Finished</option> <option  value='Cancelled' ". $cancelled ." >Cancelled</option> </select> </td>";
            } 
           // else
           //     echo "<td class='lines' > <select  style='background-color:".$color."' id='test'> <option class='pending' value='Pending' ". $pending ." >Pending</option> <option value='Finished' ". $finished ." >Finished</option> <option  value='Cancelled' ". $cancelled ." >Cancelled</option> </select> </td>";
            echo "</tr>";
            }
        ?>
 
        
    </table>
   
</body>
</html>
<?php




 /*
    else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline=='All'){    
     //   echo "SELECT * FROM tasks WHERE ipey8inos='".$value_user."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE ipey8inos='".$value_user."' ORDER BY Id ASC");
    }
    else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline=='All'){    
    //    echo "SELECT * FROM tasks WHERE state='".$value_filters."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE state='".$value_filters."' ORDER BY Id ASC");   
    }
    else if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep!='Ολα' and $value_entolh=='All'  and $value_deadline=='All' ){    
      //  echo "SELECT * FROM tasks WHERE department='".$value_dep."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE department='".$value_dep."' ORDER BY Id ASC");   
    }
    else if ($value_filters!='Ολες' and $value_user!='Ολοι'  and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline=='All'  ){    
       // echo "SELECT * FROM tasks WHERE state='".$value_filters."' AND ipey8inos='".$value_user."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE state='".$value_filters."' AND ipey8inos='".$value_user."' ORDER BY Id ASC");    
     }
    else if ($value_filters!='Ολες' and $value_user=='Ολοι'  and $value_dep!='Ολα' and $value_entolh=='All'  and $value_deadline=='All'){    
      //  echo "SELECT * FROM tasks WHERE state='".$value_filters."' AND ipey8inos='".$value_user."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE state='".$value_filters."' AND department='".$value_dep."' ORDER BY Id ASC");    
     }
    else if ($value_filters=='Ολες' and $value_user!='Ολοι'  and $value_dep!='Ολα' and $value_entolh=='All'  and $value_deadline=='All'){    
       // echo "SELECT * FROM tasks WHERE state='".$value_filters."' AND ipey8inos='".$value_user."'";
        $result = mysqli_query($con,"SELECT * FROM tasks WHERE ipey8inos='".$value_user."' AND department='".$value_dep."' ORDER BY Id ASC");    
     } 
    
     //FILTERS for ENTOLH APO
     
     else ilt = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline=='All'){
         $result = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }
     
     //FILTER for deadline
     else if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }  
     else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
          
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND state='".$value_filters."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
          $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
          $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }
     * 
     */
/*f ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline=='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline=='All'){
         $result = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline=='All'){
         $result = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline=='All'){
         $result = mysqli_query($con,"SELECT * FROM tasks WHERE ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }
     
     //FILTER for deadline
     else if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }  
     else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters=='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh=='All'  and $value_deadline!='All'){
          
           $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND state='".$value_filters."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters=='Ολες' and $value_user!='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
          $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' AND ipey8inos='".$value_user."' ORDER BY Id ASC" ); 
     }
     else if ($value_filters!='Ολες' and $value_user=='Ολοι' and $value_dep=='Ολα' and $value_entolh!='All'  and $value_deadline!='All'){
          $result = mysqli_query($con,"SELECT * FROM tasks WHERE deadline IS ".$value_deadline."  NULL AND ekdosh='".$value_entolh."' AND state='".$value_filters."' ORDER BY Id ASC" ); 
     }
     * 
     */
     ?>