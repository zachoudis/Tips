<?php
    
    $users=array("Μπατζογιάννη Θεανώ","Αλεξοπούλου Στέλλα","Ταμτάκου Σοφία","Κοντός Κρυστάλλης","Ζαχούδης Πάρης","Σπυρίδης Ιορδάνης","Σωτηράκου Νατάσα","Κωνσταντίνου Χρήστος","Κωνσταντίνου Δέσποινα");
    $length = count($users);
    $departments=array("T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","Y1","Y2","Y3","Y4","Y5","Y6","Y7","Y8","Y9","Y10","Y11");
    $persons_to_give_orders=array("Ανθιμος","Βασιλική");
    $length_dep= count($departments);
    $pending='';
    $cancelled='';
    $finished='';   
    $delayed_task=0;
    $task_ending_today=0;
    
    $ids=get_list_ids();
  
    $users_inout = array(
        array("Αλεξοπούλου Στέλλα",'45','09:00'),
        array("Αραμπέλος Νικόλας",'46',''),
        array("Αργυρίου Στέφανος",'47',''),
        array("Αυγέρος Χρήστος",'89','08:30'),
        array("Γεωργάκη Δήμητρα",'50',''),
        array("Γεωργάκης Γιάννης",'51',''),
        array("Γεωργόπουλος Νίκος",'129',''),
        array("Γκέκα Γιάννα",'53',''),    
        array("Γριβάκη Γωγώ",'148',''),
        array("Γκιόνογλου Κωνσταντίνα",'155',''),
        array("Δερβενιωτάκης Μίμης",'54','09:00'),
        array("Δίσκος Δημήτρης",'55',''),    
        array("Δουρμίσης Κώστας",'158',''),
        array("Ζαχαρόπουλος Γιάννης",'122',''),
        array("Ζαχούδης Πάρης",'149','09:00'),
        array("Κεσκιλίδου Ντίνα",'58',''),
        array("Κοντός Κρυστάλλης",'60','08:30'),
        array("Κούκα Δούκισσα",'61',''),   
        array("Κουντουρά Λία",'156',''),
        array("Κωνσταντίνου Δέσποινα",'141','10:00'),
        array("Κωνσταντίνου Χρήστος",'112','11:00'),
        array("Μαγνήσαλης Σταύρος",'143',''),
        array("Μανάκος Αντώνης",'128',''),
        array("Μενούτη Σαμπίνα",'63',''),
        array("Μπατζογιάννη Θεανώ",'67','08:30'),
        array("Παπαβασιλείου Κατερίνα",'146','09:00'),
        array("Πατσά Χριστίνα",'90',''),
        array("Παυλίδου Ελισάβετ",'83',''),
        array("Πηλείδης Γιώργος",'73',''),
        array("Πίνδος Παναγιώτης",'113',''),
        array("Πλούγαρλης Τάσος",'154',''),
        array("Σαββαΐδου Ισμήνη",'135',''),
        array("Σαρηκιάνου Γώνη",'75',''),
        array("Σπυρίδης Ιορδάνης",'77','09:00'),
        array("Σπυρόπουλος Νίκος",'78','09:00'),
        array("Σταυριανίδης Ορέστης",'101','09:00'),
        array("Σωτηράκου Νατάσα",'142','10:00'),
        array("Ταμτάκου Σοφία",'79','08:30'),
        array("Τουτζιάρη Μάγδα",'94','09:00'),
        array("Τσονούλης Νίκος",'104',''),
        array("Χαλτογιαννίδου Μπέττυ",'83','')
        );

    
    if(isset( $_POST['edit'] )){ 
        $timestamp = strtotime($_POST['date_entry']);
        $new_date_format = date('Y-m-d', $timestamp);
        
        $timestamp2 = strtotime($_POST['deadline']);
        $new_date_format2 = date('Y-m-d', $timestamp2);
        $Id = mysqli_real_escape_string($db,$_POST['Id']);
        $date_entry = mysqli_real_escape_string($db,  $new_date_format);
        $deadline = mysqli_real_escape_string($db,  $new_date_format2);
        $praktiko = mysqli_real_escape_string($db, $_POST['praktiko']);
        $description = mysqli_real_escape_string($db, $_POST['description']);
        $department=get_department($_POST['ipey8inos']);
        //$department = mysqli_real_escape_string($db, $_POST['department']);
        $ipey8ions = mysqli_real_escape_string($db, $_POST['ipey8inos']);
        $ekdosh = mysqli_real_escape_string($db, $_POST['ekdosh']);
        $comments = mysqli_real_escape_string($db, $_POST['comments']); 

        
        echo floor($Id);
        
        $result_sum=mysqli_query($db,"SELECT COUNT(Id) AS sum FROM tasks WHERE Id LIKE '%".  floor($Id).".%'  ORDER BY Id ASC");
        $row_sum = $result_sum->fetch_assoc();
        $result_ids=mysqli_query($db,"SELECT Id FROM tasks WHERE Id LIKE '%".  floor($Id).".%'  ORDER BY Id ASC");
        $array_ids=array(1);
        $j=0;
        
        echo " SUM=".$row_sum['sum'];
          while($row_ids = mysqli_fetch_array($result_ids))   {
              $array_ids[$j]=$row_ids["Id"];
              $j=$j+1;
          }   
               

       $i=$row_sum['sum']-1;   
       while ($i>=0){
            echo "<br> "."UPDATE tasks SET Id='".( $array_ids[$i]+0.01)."' WHERE Id='".  $array_ids[$i]."';";
            mysqli_query($db,"UPDATE tasks SET Id='".( $array_ids[$i]+0.01)."' WHERE Id='".  $array_ids[$i]."';");
            $i=$i-1;
        }

        if ($_POST['deadline'] == null)
            $sql = "INSERT INTO tasks (department,Id , date_entry , praktiko, description  , ipey8inos ,ekdosh, comments,state ) VALUES ('$department','".floor($Id)."','$date_entry' ,'$praktiko' , '$description'  , '$ipey8ions' ,'$ekdosh', '$comments' , 'Pending')";
        else 
            $sql = "INSERT INTO tasks (department,Id ,date_entry, deadline , praktiko, description  , ipey8inos ,ekdosh, comments,state ) VALUES ('$department','".floor($Id)."','$date_entry', '$deadline' ,'$praktiko' , '$description'  , '$ipey8ions' ,'$ekdosh', '$comments' , 'Pending')";
    
    if(mysqli_query($db, $sql)){
        echo "Records added successfully.";   
        header("Location:http://localhost/Jobs/MainPage.php"); /* Redirect browser */
    exit();}
    else
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);   
   
    }  
    if(isset( $_POST['submit'] )){ 
        $timestamp = strtotime($_POST['date_entry']);
        $new_date_format = date('Y-m-d', $timestamp);
      
        
        $timestamp2 = strtotime($_POST['deadline']);
        $new_date_format2 = date('Y-m-d', $timestamp2);
        
        $date_entry = mysqli_real_escape_string($db,  $new_date_format);
        $deadline = mysqli_real_escape_string($db,  $new_date_format2);
        $praktiko = mysqli_real_escape_string($db, $_POST['praktiko']);
        $description = mysqli_real_escape_string($db, $_POST['description']);
        $department = get_department($_POST['ipey8inos']);
        $ipey8ions = mysqli_real_escape_string($db, $_POST['ipey8inos']);
        $ekdosh = mysqli_real_escape_string($db, $_POST['ekdosh']);
        $comments = mysqli_real_escape_string($db, $_POST['comments']); 

        $Id= floor(get_last_id());
        $Id=$Id+1;
       
        if ($_POST['deadline'] == null)
            $sql = "INSERT INTO tasks (Id , date_entry , praktiko, description , department , ipey8inos ,ekdosh, comments,state ) VALUES ('$Id' , '$date_entry' ,'$praktiko' , '$description' ,'$department' , '$ipey8ions' ,'$ekdosh', '$comments' , 'Pending')";
        else 
            $sql = "INSERT INTO tasks (Id , date_entry, deadline , praktiko, description , department , ipey8inos ,ekdosh, comments,state ) VALUES ('$Id' , '$date_entry', '$deadline' ,'$praktiko' , '$description' ,'$department' , '$ipey8ions' ,'$ekdosh', '$comments' , 'Pending')";
       
        if(mysqli_query($db, $sql)){
        echo "Records added successfully.";   
        header("Location:http://localhost/Jobs/MainPage.php"); /* Redirect browser */
        exit();
    }
    else
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);     
    }  
    if(isset( $_POST['submit_inout'] )){
      
        $timestamp = strtotime($_POST['date2']);
        $new_date_format = date('y-m-d', $timestamp);
       // $date = mysqli_real_escape_string($db, $new_date_format);
        $array_in = array(41);
        
        for ($i=0;$i<41;$i++){
              $conn33 = odbc_connect('maps_connection','','');
              $sql33="SELECT day,in_time,out_time FROM Users_InOut WHERE user=".$users_inout[$i][1]." and day=#".$new_date_format."#; ";
              $result33 = odbc_exec($conn33,$sql33);
              $row33 = odbc_fetch_array($result33);
              $array_in[$i]=$row33['in_time'];
        }
        
            /*
                 if ($_POST['user'] != 'null'){
                       $conn3 = odbc_connect('maps_connection','','');
                       $user = mysqli_real_escape_string($db,  $_POST['user']);
                       $query="SELECT username FROM Users WHERE ID=".$user."; ";
                       $result = odbc_exec($conn3,$query);
                       $row = odbc_fetch_array($result);
                       $username= $row['username'];        
                 }

                 if ($_POST['date2'] == 'Select a Date'){           
                     $user = mysqli_real_escape_string($db,  $_POST['user']);
                     $sql6="SELECT user,day,in_time,out_time FROM Users_InOut WHERE user=".$user."; ";
                 }
                 else if ($_POST['user'] == 'null'){
                     $timestamp = strtotime($_POST['date2']);
                     $new_date_format = date('y-m-d', $timestamp);
                     $date = mysqli_real_escape_string($db, $new_date_format);
                     $sql6="SELECT user,day,in_time,out_time FROM Users_InOut WHERE day=#".$date."# ; ";
                 }
                 else{
                     $timestamp = strtotime($_POST['date2']);
                     $new_date_format = date('y-m-d', $timestamp);
                     $date = mysqli_real_escape_string($db, $new_date_format);
                     $user = mysqli_real_escape_string($db,  $_POST['user']);
                     $sql6="SELECT user,day , in_time,out_time FROM Users_InOut WHERE user=".$user." AND day=#".$date."# ; ";   
                 }

                 */
        
     }
 
    function get_last_id(){
          $db = mysqli_connect('localhost','root','1122','jobs');
          $sql = "SELECT MAX(Id) AS max FROM tasks ;" ;
          $result = mysqli_query($db,$sql); 
          $row = $result->fetch_assoc();
         
        return $row['max'];
        
     }
   
    function get_list_ids(){
        $temp_array = array();
        $db = mysqli_connect('localhost','root','1122','jobs');
        $sql = "SELECT Id FROM tasks" ;
        $result = mysqli_query($db,$sql); 
        $count=0;
      while($row = mysqli_fetch_array($result))   {
            $temp_array[$count++]=$row['Id'];
      }  
      return $temp_array;
    } 
     
    function change_previous_tasks($id,$ids,$state){ 
       $db = mysqli_connect('localhost','root','1122','jobs');
        //H 8esh tou prwtou original task
        $index_current= array_search($id,$ids);
        
        //
        //$index_start=  array_search(floor($id),$ids);
        
     //   echo $index_current."<br>".$index_start;
      
        
        //H epomenh apo thn 8esh tou prwtoy
        $i=$index_current+1;
        while (floor($ids[$i])==floor($id)){
            
            $sql="UPDATE tasks SET state='".$state."' WHERE id = ".$ids[$i];
            $result = mysqli_query($db,$sql);    
            $i++;
        }
        
       // for ($i=$index_start;$i<$index_current;$i++){
       //     $sql="UPDATE tasks SET state='".$state."' WHERE id = ".$ids[$i];
        //    $result = mysqli_query($db,$sql);    
       // }
    }
    
    function check_for_newer_version($id,$ids){                    
     //  $length=count($ids);
    //   $index= array_search($id,$ids);
      
    //   if ($index == $length-1){
     //      return 0;
    //   }
     //  else{
      //      $first_number=floor($id);
      //      $second_number=floor($ids[$index+1]);
      //      if ($first_number == $second_number)
      //          return 1;
      //      else 
      //          return 0;   ,
      // }
     $subvision=$id-floor($id);
      if ($subvision == 0)
        return 0;
      else
        return 1;
     }
 
    function get_name($user_check){
        if ($user_check == "kova")
            echo  '<h2 class="name" >Βασιλική Κουτάλου</h2>';
        else if ($user_check == "span")
            echo  '<h1 class="name" >Άνθιμος Σπυρίδης</h1>';
        else if ($user_check == "spio")
            echo  '<h1 class="name" >Ιορδάνης Σπυρίδης</h1>';
        else if ($user_check == "zari")
            echo  '<h1 class="name" >Ζαχούδης Πάρης</h1>';
        else if ($user_check == "mpth")
            echo  '<h1 class="name" >Μπατζογιάννη Θεανώ</h1>';
        else if ($user_check == "alst")
            echo  '<h1 class="name" >Αλεξοπούλου Στέλλα</h1>';
        else if ($user_check == "taso")
            echo  '<h1 class="name" >Ταμτάκου Σοφία</h1>';
        else if ($user_check == "kokr")
            echo  '<h1 class="name" >Κοντός Κρυστάλλης </h1>';
    }
    
    function return_name($user_check){
        if ($user_check == "kova")
            return  'Βασιλική Κουτάλου';
        else if ($user_check == "span")
            return  'Άνθιμος Σπυρίδης';
        else if ($user_check == "spio")
            return  'Ιορδάνης Σπυρίδης';
        else if ($user_check == "zari")
            return  'Ζαχούδης Πάρης';
        else if ($user_check == "mpth")
            return  'Μπατζογιάννη Θεανώ';
        else if ($user_check == "alst")
            return  'Αλεξοπούλου Στέλλα';
        else if ($user_check == "taso")
            return  'Ταμτάκου Σοφία';
        else if ($user_check == "kokr")
            return  'Κοντός Κρυστάλλης ';
    }
  
    function calculate_total_records($results_per_page){
       
         $db = mysqli_connect('localhost','root','1122','jobs');
         $sql = "SELECT COUNT(Id) AS total FROM tasks" ;
        
         $result = mysqli_query($db,$sql); 
         $row = $result->fetch_assoc();
         $total_pages = ceil($row["total"] / $results_per_page);
        
      //   echo "Total_Pages = ".$total_pages;
         return $total_pages;
     }    
  
    function change_auto_filter($user_check){
            if ($user_check=="mpth")
                 echo " <script>change('Μπατζογιάννη Θεανώ')</script>";
            else if ($user_check=="alst")
                 echo " <script>change('Αλεξοπούλου Στέλλα')</script>";
            else if ($user_check=="taso")
                echo " <script>change('Ταμτάκου Σοφία')</script>";
            else if ($user_check=="kokr")
                echo " <script>change('Κοντός Κρυστάλλης')</script>";
            else if ($user_check=="zari")
                echo " <script>change('Ζαχούδης Πάρης')</script>";
            else if ($user_check=="spio")
                echo " <script>change('Σπυρίδης Ιορδάνης')</script>";
    }
    
    function get_department($name){
        if ($name == "Μπατζογιάννη Θεανώ" || $name == "Αλεξοπούλου Στέλλα" || $name == "Σωτηράκου Νατάσα" || $name == "Κωνσταντίνου Χρήστος" || $name == "Κωνσταντίνου Δέσποινα")
            return 'Y7';
        else if ($name == "Ταμτάκου Σοφία" || $name == "Κοντός Κρυστάλλης" )
            return 'Y2';
        else if ($name == "Ζαχούδης Πάρης" || $name == "Σπυρίδης Ιορδάνης" )
            return 'Y8'; 
    }
    
    function get_name_from_username($user_check){
         if ($user_check=="mpth")
          $name='Μπατζογιάννη Θεανώ';
        else if ($user_check=="alst")
          $name='Αλεξοπούλου Στέλλα';
        else if ($user_check=="taso")
          $name='Ταμτάκου Σοφία';
        else if ($user_check=="kokr")
          $name='Κοντός Κρυστάλλης';
        else if ($user_check=="zari")
          $name='Ζαχούδης Πάρης';
        else if ($user_check=="spio")
          $name='Σπυρίδης Ιορδάνης';
        else if ($user_check=="soan")
          $name='Σωτηράκου Νατάσα';
        else if ($user_check=="kwch")
          $name='Κωνσταντίνου Χρήστος';
        else if ($user_check=="kode")
          $name='Κωνσταντίνου Δέσποινα';
        return $name;
    }
    
    function check_for_delays($user_check,$delayed_task,$ids){
        $name=  get_name_from_username($user_check);
       
        
        $today=date('Y-m-d');
        $db = mysqli_connect('localhost','root','1122','jobs');
        $result=mysqli_query($db, "SELECT deadline,state,Id FROM tasks WHERE ipey8inos='".$name."' ORDER BY Id ASC ;");
        
        while($row = mysqli_fetch_array($result)){
            if ($row['deadline']!=null){
                if ($today>$row['deadline'] && $row['state']=='Pending' && check_for_newer_version($row['Id'],$ids)!=1)            
                   $GLOBALS['delayed_task']=1;
                if ($today == $row['deadline']&& $row['state']=='Pending' && check_for_newer_version($row['Id'],$ids)!=1)
                   $GLOBALS['task_ending_today']=1;
            }
        
        }
      
    }
    
    function put_lines_description($initial_description){

        $len=strlen($initial_description);
        
        if ($len >50 && $len<100  )
           $newstr = substr_replace($initial_description, "<br>", 50, 0);
        else if ($len>100 && $len<150){
              $newstr = substr_replace($initial_description, "<br>", 50, 0);
              $newstr = substr_replace( $newstr, "<br>", 100, 0);}
        else if ($len>150 && $len<200){
            $newstr = substr_replace($initial_description, "<br>", 50, 0);
            $newstr = substr_replace( $newstr, "<br>", 100, 0);
            $newstr = substr_replace( $newstr, "<br>", 150, 0);}
        else
           $newstr=$initial_description;

        return  $newstr;
    }
    
    function check_if_null($date){
         if ($date == null)
               $finished='';
         else
               $finished=date('d/m/Y',strtotime($date)); 
         return $finished;
    }
    
    function check_id($id){
        if (($id-(int)$id)==0)
                $final_id=number_format($id,0);
            else
                $final_id=$id;
            
            return $final_id;
    }
    
    function get_old_comment($con,$id,$comment){
            $result3 = mysqli_query($con,"SELECT comments FROM tasks WHERE id=".$id);
            $row2 = $result3->fetch_assoc();
            $old_comments=$row2["comments"];      
            $comment=$old_comments."  ".$comment;
            return $comment;
            
        }
?>
