     function showhide(id) {
        var e = document.getElementById(id);
        e.style.display = (e.style.display == 'block') ? 'none' : 'block';
     }

     function edituser(str) {  
        if (str == "") {
            document.getElementById("edit_form").innerHTML = "";
            return;
        }else{
            if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
            } else {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("edit_form").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","edit_form.php?id="+str,true);
            xmlhttp.send();
        }
        document.getElementById('edit_form').style.display = "block";
     }
  
     function cancel_message(str,id){
        if (str=="Finished") 
            var person = prompt("Task Finished. Please enter a Comment ");
        else if (str=="Cancelled") 
            var person = prompt("Task Cancelled. Please enter a Comment ");
        if (person != null) { 
            change_state(str,id,person)
        }
           window.location.reload();
     }
  
     function change_state(str,id,person) {   
        if (str == ""){
            document.getElementById("txtHint").innerHTML = "";
            return;
        }else{
            if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
            } else {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","change_state.php?q="+str+"&id="+id+"&comment="+person,true);
            xmlhttp.send();  
        }
    }
    
    
    
    function update_view(str) {          
            var e = document.getElementById("user_filter2");
            var value_user = e.options[e.selectedIndex].value;
            
            var e2 = document.getElementById("task_filter2");
            var value_filters = e2.options[e2.selectedIndex].value;
                  
            var e3 = document.getElementById("dep_filter2");
            var value_dep = e3.options[e3.selectedIndex].value;
            
            var e4 = document.getElementById("deadline_filter2");
            var value_deadline = e4.options[e4.selectedIndex].value;
            
            var e5 = document.getElementById("entolh_filter2");
            var value_entolh = e5.options[e5.selectedIndex].value;
            
            var e6 = document.getElementById("last_filters2");
            var value_last=e6.checked;
           
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } 
        else {           
            if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
            } else {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };   
             
           xmlhttp.open("GET","update_view.php?str="+value_user+"&str2="+value_filters+"&str3="+value_dep+"&str4="+value_deadline+"&str5="+value_entolh+"&str6="+value_last,true);
           xmlhttp.send();          
        }
    }
       
    function checkbox_view(bool) {       
        if (bool == '1'){
            if (document.getElementById("check1"))
                document.getElementById("check2").checked=false;}
        else if (bool == '2'){
            if (document.getElementById("check2"))
                document.getElementById("check1").checked=false;}
        if (   document.getElementById("check2").checked==false &  document.getElementById("check1").checked==false)    
            window.location.reload();
               
        if (bool == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } 
        else {           
            if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
            } else {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };      
         if (bool == 1)
            xmlhttp.open("GET","delay_view.php?str="+bool+"&state="+document.getElementById("check1").checked,true);
         else if (bool == 2)
            xmlhttp.open("GET","delay_view.php?str="+bool+"&state="+document.getElementById("check2").checked,true);
         xmlhttp.send();              
    }}
     
    function validateForm() {
        var x = document.forms["form_service"]["date_entry"].value;
        var y = document.forms["form_service"]["deadline"].value;
        if (y != ''){
            if (y < x){
               alert("Εχετε Δωσει Λαθος Ημερομηνια για Deadline");
                 document.getElementById('datepicker').style.color="red";
               document.getElementById('datepicker').style.borderColor = "red";
               return false;
               }
            else
                alert("Επιτυχής Καταχώρηση")
        }
        else
            alert("Επιτυχής Καταχώρηση")
            
            
    }

    function fnExcelReport(table_name,name,state){
        var tab_text=         " <div id='panel' class='panel'>"
      //  var tab_text=tab_text+"   <img  src='logo2.jpg' class='logo' alt='yetos' style='width:379px;height:99px;'>";
  
       var tab_text=tab_text+" <table style='width:100%'> <tr><th>Firstname</th><th>Lastname</th> <th>Age</th></tr> <tr><td>Jill</td<td>Smith</td><td>50</td></tr><tr><td>Eve</td><td>Jackson</td><td>94</td></tr><tr><td>John</td><td>Doe</td><td>80</td></tr></table>";
  
        var tab_text=tab_text+"    <h1>T.i.P. Υετος " + name + "</h1> ";
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10) {dd='0'+dd} 
        if(mm<10) { mm='0'+mm } 
            today = mm+'/'+dd+'/'+yyyy;
         var tab_text=tab_text+"    <h1> " + today + "</h1> ";   
         if (state == 'Pending')
            var tab_text=tab_text+"<h2  style='color:orange'>"+state+" Tasks</h2>";
         else if (state == 'Finished')
             var tab_text=tab_text+"<h2  style='color:green'>"+state+" Tasks</h2>";
         else if (state == 'Cancelled')
             var tab_text=tab_text+"<h2  style='color:red'>"+state+" Tasks</h2>";
        var tab_text=tab_text+" </div>";
        
        tab_text =tab_text + "<table border='1px' style='font-size:20px' >";
        var textRange; 
        var j = 0;
        var tab = document.getElementById(table_name); // id of table
        var lines = tab.rows.length;
       
        // the first headline of the table
        if (lines > 0) {
            tab.rows[0].deleteCell(12);
            tab.rows[0].deleteCell(11);
            tab_text = tab_text + "<tr bgcolor='#DFDFDF'>" + tab.rows[0].innerHTML + '</tr>';
        }
        // table data lines, loop starting from 1
        for (j = 1 ; j < lines; j++) {     
           tab.rows[j].deleteCell(12);
           tab.rows[j].deleteCell(11);
           tab_text = tab_text + "<tr bgcolor='#CDE8F6'>" + tab.rows[j].innerHTML + "</tr>";    
        }

        tab_text = tab_text + "</table>";
         //  tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, "");             //remove if u want links in your table
         //  tab_text = tab_text.replace(/<img[^>]*>/gi,"");                 // remove if u want images in your table
         //  tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, "");    // reomves input params
         // console.log(tab_text); // aktivate so see the result (press F12 in browser)

     //   var ua = window.navigator.userAgent;
    //    var msie = ua.indexOf("MSIE "); 

         // if Internet Explorer
     //   if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
       //     txtArea1.document.open("txt/html","replace");
       //     txtArea1.document.write(tab_text);
       //     txtArea1.document.close();
      //      txtArea1.focus(); 
      //      sa = txtArea1.document.execCommand("SaveAs", true, "DataTableExport");
      //  }  
     //   else // other browser not tested on IE 11
         
    
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  
   
        window.location.href = window.location.href;
            // window.location.reload();
            //  return (sa);
    }   
    
    function close_function(form){ 
        document.getElementById(form).style.visibility='hidden';
        window.location.reload();
    }
    
   
